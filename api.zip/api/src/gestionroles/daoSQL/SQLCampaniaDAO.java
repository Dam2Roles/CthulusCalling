package gestionroles.daoSQL;

import gestionroles.Exceptions.DAOException;
import gestionroles.dao.DAOCampania;
import gestionroles.modelo.Campania;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SQLCampaniaDAO implements DAOCampania {

    final String insert="INSERT INTO CAMPANIA (nombre_camp,creador,descripcion) VALUES(?, ?, ?)";
	final String update="UPDATE CAMPANIA SET creador = ?, descripcion = ? where nombre_camp = ? ";
	final String delete="DELETE FROM CAMPANIA where nombre_camp = ?";
	final String obtenerTodos="SELECT nombre_camp, descripcion, creador from CAMPANIA";
	final String obtenerUno="SELECT nombre_camp, descripcion, creador from CAMPANIA where nombre_camp = ?";
	final String obtenerCampUsu = "SELECT c.nombre_camp,c.creador,c.descripcion FROM PERSONAJE p,CAMPANIA c WHERE p.nombre_usuario = ?"
								  + " AND p.nombre_campania = c.nombre_camp";
	final String obtenerCreador = "SELECT creador FROM CAMPANIA WHERE nombre_camp = ?";
	final String obtenerDescripcion = "SELECT descripcion FROM CAMPANIA WHERE nombre_camp = ?";
	
	private Connection con;
	
	public SQLCampaniaDAO(Connection con) {
		this.con=con;
	}

	@Override
	public void insertar(Campania a) throws DAOException {
		PreparedStatement stat= null;
		try  {
			stat=con.prepareStatement(insert);
			stat.setString(1,a.getNombreCampania());
                     stat.setString(2,a.getCreador());
			stat.setString(3,a.getDescripcion());
			
			stat.executeUpdate();
			if(stat.executeUpdate()==0) {
				throw new DAOException("Puede que no se haya guardado la campa�a");
			}
		} catch (SQLException ex) {
			throw new DAOException("Error en sql ",ex);
		}
		finally {
			if (stat != null) {
				try {
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		
	}

	@Override
	public void modificar(Campania a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(update);
			stat.setString(1,a.getNombreCampania());
                     stat.setString(2,a.getCreador());
			stat.setString(3,a.getDescripcion());
			
			
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se hayan guardado los cambios de la campa�a");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
		
	}

	@Override
	public void eliminar(Campania a) throws DAOException {
		PreparedStatement stat= null;
		try {
			stat=con.prepareStatement(delete);
			stat.setString(1, a.getNombreCampania());
		stat.executeUpdate();
		if(stat.executeUpdate()==0) {
			throw new DAOException("Puede que no se haya borrado la campa�a");
		}
	} catch (SQLException ex) {
		throw new DAOException("Error en sql ",ex);
	}
	finally {
		if (stat != null) {
			try {
				stat.close();	
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		}
	}
	}

	
	private Campania convertir(ResultSet rs) throws SQLException{
		String nombre = rs.getString("nombre_camp");
             String creador= rs.getString("creador");
		String descripcion = rs.getString("descripcion");
		
		Campania campania = new Campania (nombre,creador,descripcion);
		
		return campania;
	}
	
	
	//a�adido
    private String convertirCreador(ResultSet rs) throws SQLException{
        
        String creador = rs.getString("creador");

        return creador;
    }
	
    
    //a�adido
    private String convertirDescripcion(ResultSet rs) throws SQLException{
        
        String descripcion = rs.getString("descripcion");

        return descripcion;
    }
    
    
	
	@Override
	public List<Campania> obtenerTodos() throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		List <Campania> campanias = new ArrayList<>();
		try {
			stat=con.prepareStatement(obtenerTodos);
			rs=stat.executeQuery();
			while(rs.next()) {
				campanias.add(convertir(rs));
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return campanias;
	}


	@Override
	public Campania obtener(String nombre) throws DAOException {
		PreparedStatement stat = null;
		ResultSet rs = null;
		Campania camp = null;
		try {
			stat=con.prepareStatement(obtenerUno);
			stat.setString(1, nombre);
			rs=stat.executeQuery();
			if(rs.next()) {
				camp=convertir(rs);
			} else {
				throw new DAOException("No se ha encontrado ese registro");
			}
			}catch(SQLException ex) {
				throw new DAOException("Error en sql ",ex);
			}
		finally{	
			if (rs != null) {
				try {	
					rs.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
			if (stat != null) {
				try {	
					stat.close();	
				}catch(SQLException ex) {
					throw new DAOException("Error en sql ",ex);
				}
			}
		}
		return camp;
}
	
	//a�adido
	 @Override
	    public String obtenerCreador(String nombreCamp) throws DAOException {
	        PreparedStatement stat = null;
	        ResultSet rs = null;
	        String creador = null;
	        try {
	            stat = con.prepareStatement(obtenerCreador);
	            stat.setString(1, nombreCamp);
	            rs = stat.executeQuery();
	            if (rs.next()) {
	                creador = convertirCreador(rs);
	            } else {
	                throw new DAOException("No se ha encontrado ese registro");
	            }
	        } catch (SQLException ex) {
	            throw new DAOException("Error en sql ", ex);
	        } finally {
	            if (rs != null) {
	                try {
	                    rs.close();
	                } catch (SQLException ex) {
	                    throw new DAOException("Error en sql ", ex);
	                }
	            }
	            if (stat != null) {
	                try {
	                    stat.close();
	                } catch (SQLException ex) {
	                    throw new DAOException("Error en sql ", ex);
	                }
	            }
	        }
	        return creador;
	    }
	
	 
	 //a�adido
	 
	 @Override
	    public String obtenerDescripcion(String nombreCamp) throws DAOException {
	        PreparedStatement stat = null;
	        ResultSet rs = null;
	        String descripcion = null;
	        try {
	            stat = con.prepareStatement(obtenerDescripcion);
	            stat.setString(1, nombreCamp);
	            rs = stat.executeQuery();
	            if (rs.next()) {
	                descripcion = convertirDescripcion(rs);
	            } else {
	                throw new DAOException("No se ha encontrado ese registro");
	            }
	        } catch (SQLException ex) {
	            throw new DAOException("Error en sql ", ex);
	        } finally {
	            if (rs != null) {
	                try {
	                    rs.close();
	                } catch (SQLException ex) {
	                    throw new DAOException("Error en sql ", ex);
	                }
	            }
	            if (stat != null) {
	                try {
	                    stat.close();
	                } catch (SQLException ex) {
	                    throw new DAOException("Error en sql ", ex);
	                }
	            }
	        }
	        return descripcion;
	    }
	 
	 

	@Override
    public List<Campania> obtenerCampaniasUsuario(String usuario) throws DAOException {
        PreparedStatement stat = null;
        ResultSet rs = null;
        List<Campania> campanias = new ArrayList<>();
        try {
            stat = con.prepareStatement(obtenerCampUsu);
            stat.setString(1, usuario);
            rs = stat.executeQuery();
            while (rs.next()) {
                campanias.add(convertir(rs));
            }
        } catch (SQLException ex) {
            throw new DAOException("Error en sql ", ex);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    throw new DAOException("Error en sql ", ex);
                }
            }
        }
        return campanias;
    }
     


}
