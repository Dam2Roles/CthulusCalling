package gestionroles.modelo;

public class Herida {

	String nombreHerida;
	int idPersonaje;

	public Herida(String nombreHerida, int idPersonaje) {
		this.nombreHerida = nombreHerida;
		this.idPersonaje = idPersonaje;
	}

	public String getNombreHerida() {
		return nombreHerida;
	}

	public void setNombreHerida(String nombreHerida) {
		this.nombreHerida = nombreHerida;
	}

	public int getIdPersonaje() {
		return idPersonaje;
	}

	public void setIdPersonaje(int idPersonaje) {
		this.idPersonaje = idPersonaje;
	}

	@Override
	public String toString() {
		return "Herida: " + getNombreHerida() + " idPersonaje: " + getIdPersonaje();
	}

}
