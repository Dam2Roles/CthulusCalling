package gestionroles.modelo;

public class Familia {
	String familiar;
	int idPersonaje;

	public Familia(String familiar, int idPersonaje) {
		this.familiar = familiar;
		this.idPersonaje = idPersonaje;
	}

	public String getFamiliar() {
		return familiar;
	}

	public void setFamiliar(String familiar) {
		this.familiar = familiar;
	}

	public int getIdPersonaje() {
		return idPersonaje;
	}

	public void setIdPersonaje(int idPersonaje) {
		this.idPersonaje = idPersonaje;
	}

	@Override
	public String toString() {
		return "Familiar: " + getFamiliar() + " idPersonaje: " + getIdPersonaje();
	}

}
