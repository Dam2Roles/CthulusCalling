package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Propiedad;


public interface DAOPropiedad extends DAO<Propiedad>{
    

    List<Propiedad> obtenerLista(int id) throws DAOException;
    
}
