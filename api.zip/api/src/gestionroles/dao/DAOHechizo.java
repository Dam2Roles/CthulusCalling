package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Hechizo;


public interface DAOHechizo extends DAO<Hechizo> {
    
  
    List<Hechizo> obtenerLista(int id) throws DAOException;
    
    
}
