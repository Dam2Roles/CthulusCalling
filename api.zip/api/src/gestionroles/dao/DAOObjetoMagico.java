package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.ObjetoMagico;


public interface DAOObjetoMagico extends DAO<ObjetoMagico>{
    
    

    List<ObjetoMagico> obtenerLista(int id) throws DAOException;
}
