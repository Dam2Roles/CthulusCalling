package gestionroles.modelo;

public class SerEncontrado {

	String nombreSer;
	int idPersonaje;

	public SerEncontrado(String nombreSer, int idPersonaje) {
		this.nombreSer = nombreSer;
		this.idPersonaje = idPersonaje;
	}

	public String getNombreSer() {
		return nombreSer;
	}

	public void setNombreSer(String nombreSer) {
		this.nombreSer = nombreSer;
	}

	public int getIdPersonaje() {
		return idPersonaje;
	}

	public void setIdPersonaje(int idPersonaje) {
		this.idPersonaje = idPersonaje;
	}

	@Override
	public String toString() {
		return "Ser Encontrado: " + getNombreSer() + " idPersonaje:" + getIdPersonaje();
	}
}
