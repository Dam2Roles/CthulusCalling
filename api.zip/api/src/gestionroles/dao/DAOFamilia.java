package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Familia;


public interface DAOFamilia extends DAO<Familia> {
    

    List<Familia> obtenerLista(int id) throws DAOException;
    
}
