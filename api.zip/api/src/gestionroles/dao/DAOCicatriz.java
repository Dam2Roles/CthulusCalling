package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Cicatriz;


public interface DAOCicatriz  extends DAO<Cicatriz>{
    
    
    List<Cicatriz> obtenerLista(int id) throws DAOException;
    
}
