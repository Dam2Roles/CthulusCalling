package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Armamento;


public interface DAOArmamento extends DAO<Armamento>{
    
    List<Armamento> obtenerLista(int id) throws DAOException;
    
    
}
