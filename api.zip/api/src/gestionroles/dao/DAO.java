package gestionroles.dao;
/*Es un dao generico
 * en el t es la clase
 * y k la clase primaria*/
import java.util.List;

import gestionroles.Exceptions.DAOException;

public interface DAO <T> {
	void insertar(T a) throws DAOException;
	void modificar(T a) throws DAOException;
	void eliminar(T a) throws DAOException;
	List<T>obtenerTodos() throws DAOException;
}
