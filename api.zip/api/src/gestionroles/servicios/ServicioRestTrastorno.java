package gestionroles.servicios;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

import java.net.URI;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import gestionroles.Exceptions.DAOException;
import gestionroles.daoSQL.SQLTrastornoDAO;
import gestionroles.modelo.Trastorno;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Path("/trastorno")
public class ServicioRestTrastorno {

	@Inject
	private DataSource dataSource;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getTrastorno() {

		Response.Status responseStatus = Response.Status.OK;
		List<Trastorno> TrastornoRg = new LinkedList<Trastorno>();

		try {
			Connection connection = dataSource.getConnection();
			SQLTrastornoDAO man = new SQLTrastornoDAO(connection);
			TrastornoRg = man.obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(TrastornoRg).build();
		else
			return Response.status(responseStatus).build();
	}


	@PUT
	@Path("/{nombre_arma}")
	@Consumes(APPLICATION_JSON)
	public Response putTrastorno(@PathParam("nombre_arma") String id, Trastorno Trastorno) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLTrastornoDAO man = new SQLTrastornoDAO(connection);
			man.modificar(Trastorno);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	@POST
	@Consumes(APPLICATION_JSON)
	public Response postTrastorno(@Context UriInfo uriInfo, Trastorno Trastorno) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			Connection connection = dataSource.getConnection();
			SQLTrastornoDAO man = new SQLTrastornoDAO(connection);
			man.insertar(Trastorno);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

	/*
	@DELETE
	@Path("/{nombre_arma}")
	public Response deleteTrastorno(@PathParam("nombre_arma") Trastorno Trastorno) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLTrastornoDAO man = new SQLTrastornoDAO(connection);
			man.eliminar(Trastorno);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
	*/
}
