package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Titulo;


public interface DAOTitulo extends DAO<Titulo>{
    

    List<Titulo> obtenerLista(int id) throws DAOException;
}
