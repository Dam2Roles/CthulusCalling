package gestionroles.modelo;

public class Campania {
	
	public String nombreCampania;
	public String creador;
	public String descripcion;

	public Campania(String nombreCampania, String creador, String descripcion) {
		this.nombreCampania = nombreCampania;
		this.creador = creador;
		this.descripcion = descripcion;
	}

	public Campania() {

	}

	public String getNombreCampania() {
		return nombreCampania;
	}

	public void setNombreCampania(String nombreCampania) {
		this.nombreCampania = nombreCampania;
	}

	public String getCreador() {
		return creador;
	}

	public void setCreador(String creador) {
		this.creador = creador;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Nombre: " + nombreCampania + "\n Creador: " + creador + "\n Descripcion:" + descripcion;
	}

}
