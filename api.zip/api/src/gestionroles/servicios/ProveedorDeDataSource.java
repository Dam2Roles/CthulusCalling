package gestionroles.servicios;

import javax.annotation.Resource;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.sql.DataSource;

@ApplicationScoped
public class ProveedorDeDataSource {
	
	@Resource(name="jdbc/ServicioRest")
	@Produces
	private DataSource dataSource;

}
