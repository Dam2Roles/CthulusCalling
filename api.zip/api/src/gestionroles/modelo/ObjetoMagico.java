package gestionroles.modelo;


public class ObjetoMagico {
 
	  String nombreObjeto;
	    int idPersonaje;

	    public ObjetoMagico(String nombreObjeto, int idPersonaje) {
	        this.nombreObjeto = nombreObjeto;
	        this.idPersonaje = idPersonaje;
	    }
	    
	    

	    public String getNombreObjeto() {
	        return nombreObjeto;
	    }

	    public void setNombreObjeto(String nombreObjeto) {
	        this.nombreObjeto = nombreObjeto;
	    }

	    public int getIdPersonaje() {
	        return idPersonaje;
	    }

	    public void setIdPersonaje(int idPersonaje) {
	        this.idPersonaje = idPersonaje;
	    }

	    @Override
	    public String toString() {
	        return "ObjetoMagico: " + getNombreObjeto() + " idPersonaje: " + getIdPersonaje() + '}';
	    }
	    
	    
    
}
