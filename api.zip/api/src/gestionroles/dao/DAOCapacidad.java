package gestionroles.dao;

import java.util.List;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Capacidad;


public interface DAOCapacidad extends DAO<Capacidad>{
    
    List<Capacidad> obtenerLista(int id) throws DAOException;
    
}
