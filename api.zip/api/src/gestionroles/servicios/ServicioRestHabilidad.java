package gestionroles.servicios;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import java.net.URI;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import javax.inject.Inject;
import javax.sql.DataSource;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import gestionroles.Exceptions.DAOException;
import gestionroles.daoSQL.SQLHabilidadDAO;
import gestionroles.modelo.Habilidad;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
@Path("/habilidad")
public class ServicioRestHabilidad {

	@Inject
	private DataSource dataSource;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getHabilidad() {

		Response.Status responseStatus = Response.Status.OK;
		List<Habilidad> habilidadRg = new LinkedList<Habilidad>();

		try {
			Connection connection = dataSource.getConnection();
			SQLHabilidadDAO man = new SQLHabilidadDAO(connection);
			habilidadRg = man.obtenerTodos();

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(habilidadRg).build();
		else
			return Response.status(responseStatus).build();
	}

	@GET
	@Path("/{nombre_habilidad}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getHabilidad(@PathParam("nombre_habilidad") String idHabilidad) {

		Response.Status responseStatus = Response.Status.OK;
		Habilidad hab = null;
		try {
			Connection connection = dataSource.getConnection();
			SQLHabilidadDAO man = new SQLHabilidadDAO(connection);
			hab = man.obtener(idHabilidad);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK)
			return Response.ok(hab).build();
		else
			return Response.status(responseStatus).build();
	}

	@PUT
	@Path("/{nombre_habilidad}")
	@Consumes(APPLICATION_JSON)
	public Response putHabilidad(@PathParam("nombre_habilidad") String id, Habilidad hab) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLHabilidadDAO man = new SQLHabilidadDAO(connection);
			man.modificar(hab);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}
		return Response.status(responseStatus).build();
	}

	@POST
	@Consumes(APPLICATION_JSON)
	public Response postHabilidad(@Context UriInfo uriInfo, Habilidad hab) {

		Response.Status responseStatus = Response.Status.OK;
		int generatedId = -1;

		try {
			Connection connection = dataSource.getConnection();
			SQLHabilidadDAO man = new SQLHabilidadDAO(connection);
			man.insertar(hab);

		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			e.printStackTrace();
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		if (responseStatus == Response.Status.OK) {
			UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
			URI uri = uriBuilder.path(Integer.toString(generatedId)).build();
			return Response.created(uri).build();
		} else
			return Response.status(responseStatus).build();
	}

	
	/*
	@DELETE
	@Path("/{nombre_habilidad}")
	public Response deleteHabilidad(@PathParam("nombre_habilidad") Habilidad hab) {

		Response.Status responseStatus = Response.Status.OK;

		try {
			Connection connection = dataSource.getConnection();
			SQLHabilidadDAO man = new SQLHabilidadDAO(connection);
			man.eliminar(hab);
		} catch (SQLException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		} catch (DAOException e) {
			responseStatus = Response.Status.INTERNAL_SERVER_ERROR;
		}

		return Response.status(responseStatus).build();
	}
	*/
}