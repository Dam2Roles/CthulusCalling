package gestionroles.dao;

import gestionroles.Exceptions.DAOException;
import gestionroles.modelo.Arma;


public interface DAOArma  extends DAO<Arma>{
    
    Arma obtener (String nombreArma) throws DAOException;
    
}
